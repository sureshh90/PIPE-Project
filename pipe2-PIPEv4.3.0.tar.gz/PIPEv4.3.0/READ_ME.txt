In order to run PIPE tool, execute the appropriate file within the PIPE directory:
Windows: 	launch.bat
Linux:		launch.sh