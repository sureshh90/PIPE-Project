/**
 * This is a placeholder for a class to be added as part of the
 * support of exponential distributions.
 * 
 * This will be the gui part of the place watcher simulation.
 * 
 * @author David Patterson 
 *
 */

package pipe.modules.iai;

import pipe.modules.interfaces.IModule;

class SimulationPlaceWatcherDialog
{
	
	protected SimulationPlaceWatcherDialog( String _moduleName, 
		IModule _parent )
	{
		// nothing here.
	}
}