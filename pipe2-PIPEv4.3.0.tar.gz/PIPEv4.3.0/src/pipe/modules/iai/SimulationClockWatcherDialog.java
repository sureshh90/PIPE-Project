/**
 * This is a placeholder for a class to be added as part of the
 * support of exponential distributions.
 * 
 * This will be the gui part of the clock watcher simulation.
 * 
 * @author David Patterson 
 *
 */

package pipe.modules.iai;

import pipe.modules.interfaces.IModule;

class SimulationClockWatcherDialog
{
	
	protected SimulationClockWatcherDialog( String _moduleName, 
		IModule _parent )
	{
		// nothing here.
	}
}