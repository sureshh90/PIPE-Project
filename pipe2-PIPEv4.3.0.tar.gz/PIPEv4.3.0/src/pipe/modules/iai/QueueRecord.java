package pipe.modules.iai;

/**
 * This is a placeholder for a class to be added as part of the
 * support of exponential distributions.
 * 
 * @author David Patterson 
 *
 */
class QueueRecord
{
	// nothing here for now
}
