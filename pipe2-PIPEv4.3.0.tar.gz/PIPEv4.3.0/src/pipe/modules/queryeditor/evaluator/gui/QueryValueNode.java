/**
 * 
 */
package pipe.modules.queryeditor.evaluator.gui;

import pipe.modules.queryeditor.gui.performancetrees.PerformanceTreeNode;

/**
 * @author dazz
 * 
 */
class QueryValueNode extends QueryTreeNode
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= -1408409803454075267L;

	public QueryValueNode(PerformanceTreeNode n) {
		super(n);
	}

}
