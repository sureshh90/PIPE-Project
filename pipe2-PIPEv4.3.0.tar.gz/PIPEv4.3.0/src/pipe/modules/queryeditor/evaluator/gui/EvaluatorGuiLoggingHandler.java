/**
 * 
 */
package pipe.modules.queryeditor.evaluator.gui;

import java.util.logging.Logger;

/**
 * @author dazz
 * 
 */
interface EvaluatorGuiLoggingHandler
{
	public static final String	pipeEvaluatorGui	= "pipe.modules.queryeditor.evaluator.gui";
	public static Logger		logger				= Logger.getLogger(EvaluatorGuiLoggingHandler.pipeEvaluatorGui);
}
