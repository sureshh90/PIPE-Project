package pipe.gui;

public interface Translatable
{
    public void translate(int x, int y);
}
