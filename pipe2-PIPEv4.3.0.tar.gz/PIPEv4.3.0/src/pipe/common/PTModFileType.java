/*
 * Created on Jan 21, 2008
 * Created by darrenbrien
 */
package pipe.common;

public enum PTModFileType
{
	MODEL,
	RESULT,
	SEQUENTIAL,
	PTD,
	DIST,
	CONV,
	PROBININTERVAL,
	PROBINSTATES,
	MOMENT,
	FR,
	SSP,
	SSS,
	STATESATTIME,
	ININTERVAL
}
