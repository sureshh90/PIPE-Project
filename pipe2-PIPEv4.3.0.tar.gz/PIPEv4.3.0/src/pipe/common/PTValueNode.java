/*
 * Created on Jan 21, 2008
 * Created by darrenbrien
 */
package pipe.common;

public enum PTValueNode
{
	ACTIONS, STATES, BOOL, STATEFUNCTION, DISCON, ARITHCOMP, ARITHOP, NUM, MACRO, ARGUMENT
}