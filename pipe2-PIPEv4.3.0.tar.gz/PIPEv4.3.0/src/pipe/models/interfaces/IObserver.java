package pipe.models.interfaces;

public interface IObserver
{
    void update();
}
