/*
 * EmptyNetException.java
 *
 * Created on 8 / agost / 2007, 10:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pipe.exceptions;

/**
 *
 * @author marc
 */
public class EmptyNetException extends Exception{}
