package pipe.exceptions;

public class EnterOptionsException extends Exception {
   
   public EnterOptionsException() {
      super();
   }
   
}
